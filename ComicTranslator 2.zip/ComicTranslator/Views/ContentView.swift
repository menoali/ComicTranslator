import SwiftUI
import UniformTypeIdentifiers

// MARK: - Main Content View (Library)
struct ContentView: View {
    @StateObject private var viewModel = LibraryViewModel()
    @State private var showFilePicker = false
    @State private var selectedComic: ComicBook?
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()
                
                if viewModel.comics.isEmpty {
                    EmptyLibraryView(showFilePicker: $showFilePicker)
                } else {
                    ComicGridView(
                        viewModel: viewModel,
                        selectedComic: $selectedComic,
                        showFilePicker: $showFilePicker
                    )
                }
                
                if viewModel.isImporting {
                    ImportingOverlay()
                }
            }
            .navigationTitle("مكتبة الكوميكس")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: { showFilePicker = true }) {
                        Label("إضافة", systemImage: "plus.circle.fill")
                            .font(.headline)
                    }
                }
            }
            .fileImporter(
                isPresented: $showFilePicker,
                allowedContentTypes: [UTType(filenameExtension: "cbz") ?? .data],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first {
                        viewModel.importCBZ(url: url)
                    }
                case .failure(let error):
                    viewModel.errorMessage = error.localizedDescription
                    viewModel.showError = true
                }
            }
            .alert("خطأ", isPresented: $viewModel.showError) {
                Button("حسناً", role: .cancel) {}
            } message: {
                Text(viewModel.errorMessage ?? "حدث خطأ غير معروف")
            }
            .sheet(item: $selectedComic) { comic in
                ReaderView(comic: comic)
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

// MARK: - Empty Library View
struct EmptyLibraryView: View {
    @Binding var showFilePicker: Bool
    
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "books.vertical.fill")
                .font(.system(size: 80))
                .foregroundColor(.orange)
            
            Text("مكتبتك فارغة")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("أضف ملفات CBZ لبدء القراءة والترجمة")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            Button(action: { showFilePicker = true }) {
                Label("إضافة كوميكس", systemImage: "plus")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding(.horizontal, 32)
                    .padding(.vertical, 14)
                    .background(Color.orange)
                    .cornerRadius(14)
            }
        }
        .padding()
    }
}

// MARK: - Comic Grid View
struct ComicGridView: View {
    @ObservedObject var viewModel: LibraryViewModel
    @Binding var selectedComic: ComicBook?
    @Binding var showFilePicker: Bool
    
    let columns = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(viewModel.comics) { comic in
                    ComicCardView(comic: comic)
                        .onTapGesture {
                            selectedComic = comic
                        }
                }
                
                // Add button card
                Button(action: { showFilePicker = true }) {
                    VStack(spacing: 12) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.orange)
                        Text("إضافة كوميكس")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 180)
                    .background(Color(.secondarySystemGroupedBackground))
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.orange.opacity(0.4), style: StrokeStyle(lineWidth: 2, dash: [6]))
                    )
                }
            }
            .padding()
        }
    }
}

// MARK: - Comic Card View
struct ComicCardView: View {
    let comic: ComicBook
    
    var translatedCount: Int {
        comic.pages.filter { $0.translationStatus.isTranslated }.count
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Cover image
            if let firstPage = comic.pages.first {
                Image(uiImage: firstPage.originalImage)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 160)
                    .clipped()
                    .cornerRadius(12, corners: [.topLeft, .topRight])
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(comic.title)
                    .font(.caption)
                    .fontWeight(.semibold)
                    .lineLimit(2)
                
                Text("\(comic.pages.count) صفحة • \(translatedCount) مترجمة")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 8)
        }
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 2)
    }
}

// MARK: - Importing Overlay
struct ImportingOverlay: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
            
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.5)
                    .tint(.white)
                Text("جارٍ تحميل الكوميكس...")
                    .foregroundColor(.white)
                    .font(.headline)
            }
            .padding(32)
            .background(.ultraThinMaterial)
            .cornerRadius(20)
        }
    }
}

// MARK: - Corner Radius Extension
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}
