import SwiftUI

// MARK: - Reader View
struct ReaderView: View {
    @StateObject private var viewModel: ReaderViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var showControls = true
    
    init(comic: ComicBook) {
        _viewModel = StateObject(wrappedValue: ReaderViewModel(comic: comic))
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            // Page Swipe View
            TabView(selection: $viewModel.currentPageIndex) {
                ForEach(Array(viewModel.comic.pages.enumerated()), id: \.element.id) { index, page in
                    PageView(page: page)
                        .tag(index)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                showControls.toggle()
                            }
                        }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            
            // Controls overlay
            if showControls {
                VStack {
                    // Top Bar
                    TopBarView(
                        title: viewModel.comic.title,
                        currentPage: viewModel.currentPageIndex + 1,
                        totalPages: viewModel.totalPages,
                        onDismiss: { dismiss() }
                    )
                    
                    Spacer()
                    
                    // Bottom Bar
                    BottomBarView(viewModel: viewModel)
                }
                .transition(.opacity)
            }
            
            // Translating All Overlay
            if viewModel.isTranslatingAll {
                TranslatingAllOverlay(
                    progress: viewModel.translationProgress,
                    current: Int(viewModel.translationProgress * Double(viewModel.totalPages)),
                    total: viewModel.totalPages
                )
            }
        }
        .alert("خطأ في الترجمة", isPresented: $viewModel.showError) {
            Button("حسناً", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "حدث خطأ غير معروف")
        }
        .statusBar(hidden: !showControls)
    }
}

// MARK: - Page View
struct PageView: View {
    let page: ComicPage
    
    var displayImage: UIImage {
        if let translated = page.translatedImage {
            return translated
        }
        return page.originalImage
    }
    
    var body: some View {
        ZStack {
            Image(uiImage: displayImage)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            // Translating indicator
            if page.translationStatus.isTranslating {
                VStack(spacing: 12) {
                    ProgressView()
                        .scaleEffect(1.5)
                        .tint(.white)
                    Text("جارٍ الترجمة...")
                        .foregroundColor(.white)
                        .font(.headline)
                }
                .padding(24)
                .background(.ultraThinMaterial)
                .cornerRadius(16)
            }
        }
    }
}

// MARK: - Top Bar
struct TopBarView: View {
    let title: String
    let currentPage: Int
    let totalPages: Int
    let onDismiss: () -> Void
    
    var body: some View {
        HStack {
            Button(action: onDismiss) {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white)
                    .shadow(radius: 4)
            }
            
            Spacer()
            
            VStack(spacing: 2) {
                Text(title)
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text("صفحة \(currentPage) من \(totalPages)")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.8))
            }
            
            Spacer()
            
            // Placeholder for symmetry
            Image(systemName: "xmark.circle.fill")
                .font(.title2)
                .foregroundColor(.clear)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.7), .clear],
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }
}

// MARK: - Bottom Bar
struct BottomBarView: View {
    @ObservedObject var viewModel: ReaderViewModel
    
    var currentPage: ComicPage {
        viewModel.currentPage
    }
    
    var body: some View {
        VStack(spacing: 12) {
            // Page indicator dots
            PageIndicatorView(
                current: viewModel.currentPageIndex,
                total: viewModel.totalPages
            )
            
            // Action buttons
            HStack(spacing: 16) {
                // Translate current page
                TranslateButton(
                    status: currentPage.translationStatus,
                    action: { viewModel.translateCurrentPage() }
                )
                
                // Translate all pages
                Button(action: { viewModel.translateAllPages() }) {
                    Label("ترجمة الكل", systemImage: "wand.and.stars")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(Color.purple)
                        .cornerRadius(20)
                }
                .disabled(viewModel.isTranslatingAll)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .background(
            LinearGradient(
                colors: [.clear, .black.opacity(0.7)],
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }
}

// MARK: - Translate Button
struct TranslateButton: View {
    let status: TranslationStatus
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if status.isTranslating {
                    ProgressView()
                        .scaleEffect(0.8)
                        .tint(.white)
                } else {
                    Image(systemName: status.isTranslated ? "checkmark.circle.fill" : "translate")
                }
                
                Text(status.isTranslated ? "مترجمة ✓" : "ترجمة الصفحة")
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
            .foregroundColor(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            .background(status.isTranslated ? Color.green : Color.orange)
            .cornerRadius(20)
        }
        .disabled(status.isTranslating || status.isTranslated)
    }
}

// MARK: - Page Indicator
struct PageIndicatorView: View {
    let current: Int
    let total: Int
    
    var visibleRange: Range<Int> {
        let maxVisible = 7
        if total <= maxVisible {
            return 0..<total
        }
        let half = maxVisible / 2
        let start = max(0, min(current - half, total - maxVisible))
        return start..<(start + maxVisible)
    }
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(visibleRange, id: \.self) { index in
                Circle()
                    .fill(index == current ? Color.white : Color.white.opacity(0.4))
                    .frame(width: index == current ? 8 : 5, height: index == current ? 8 : 5)
                    .animation(.spring(), value: current)
            }
        }
    }
}

// MARK: - Translating All Overlay
struct TranslatingAllOverlay: View {
    let progress: Double
    let current: Int
    let total: Int
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.6).ignoresSafeArea()
            
            VStack(spacing: 20) {
                Image(systemName: "wand.and.stars")
                    .font(.system(size: 40))
                    .foregroundColor(.purple)
                
                Text("جارٍ ترجمة الكوميكس")
                    .font(.headline)
                    .foregroundColor(.white)
                
                ProgressView(value: progress)
                    .tint(.purple)
                    .frame(width: 240)
                
                Text("الصفحة \(current) من \(total)")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                
                Text("هذا قد يأخذ بعض الوقت...")
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.6))
            }
            .padding(32)
            .background(.ultraThinMaterial)
            .cornerRadius(24)
        }
    }
}
