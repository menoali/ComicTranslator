import SwiftUI
import Foundation

// MARK: - Comic Book Model
struct ComicBook: Identifiable {
    let id = UUID()
    var title: String
    var pages: [ComicPage]
    var dateAdded: Date = Date()
}

// MARK: - Comic Page Model
struct ComicPage: Identifiable {
    let id = UUID()
    var pageNumber: Int
    var originalImage: UIImage
    var translatedImage: UIImage?
    var translationStatus: TranslationStatus = .notTranslated
}

// MARK: - Translation Status
enum TranslationStatus {
    case notTranslated
    case translating
    case translated
    case failed(String)
    
    var displayText: String {
        switch self {
        case .notTranslated: return "لم تتم الترجمة"
        case .translating: return "جارٍ الترجمة..."
        case .translated: return "تمت الترجمة ✓"
        case .failed(let msg): return "فشلت الترجمة: \(msg)"
        }
    }
    
    var isTranslating: Bool {
        if case .translating = self { return true }
        return false
    }
    
    var isTranslated: Bool {
        if case .translated = self { return true }
        return false
    }
}
