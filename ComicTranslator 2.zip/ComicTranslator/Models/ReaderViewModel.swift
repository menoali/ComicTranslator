import SwiftUI
import Foundation

// MARK: - Reader ViewModel
class ReaderViewModel: ObservableObject {
    @Published var comic: ComicBook
    @Published var currentPageIndex: Int = 0
    @Published var isTranslatingAll = false
    @Published var translationProgress: Double = 0
    @Published var errorMessage: String?
    @Published var showError = false
    
    private let gemini = GeminiService()
    
    init(comic: ComicBook) {
        self.comic = comic
    }
    
    var currentPage: ComicPage {
        comic.pages[currentPageIndex]
    }
    
    var totalPages: Int {
        comic.pages.count
    }
    
    // MARK: - Translate Current Page
    func translateCurrentPage() {
        guard !comic.pages[currentPageIndex].translationStatus.isTranslating else { return }
        
        comic.pages[currentPageIndex].translationStatus = .translating
        
        Task {
            do {
                let originalImage = comic.pages[currentPageIndex].originalImage
                let translatedImage = try await gemini.translatePage(originalImage)
                
                await MainActor.run {
                    self.comic.pages[self.currentPageIndex].translatedImage = translatedImage
                    self.comic.pages[self.currentPageIndex].translationStatus = .translated
                }
            } catch {
                await MainActor.run {
                    self.comic.pages[self.currentPageIndex].translationStatus = .failed(error.localizedDescription)
                    self.errorMessage = error.localizedDescription
                    self.showError = true
                }
            }
        }
    }
    
    // MARK: - Translate All Pages
    func translateAllPages() {
        isTranslatingAll = true
        translationProgress = 0
        
        Task {
            let total = Double(comic.pages.count)
            
            for index in 0..<comic.pages.count {
                guard !comic.pages[index].translationStatus.isTranslated else {
                    await MainActor.run {
                        self.translationProgress = Double(index + 1) / total
                    }
                    continue
                }
                
                await MainActor.run {
                    self.comic.pages[index].translationStatus = .translating
                }
                
                do {
                    let originalImage = comic.pages[index].originalImage
                    let translatedImage = try await gemini.translatePage(originalImage)
                    
                    await MainActor.run {
                        self.comic.pages[index].translatedImage = translatedImage
                        self.comic.pages[index].translationStatus = .translated
                        self.translationProgress = Double(index + 1) / total
                    }
                } catch {
                    await MainActor.run {
                        self.comic.pages[index].translationStatus = .failed(error.localizedDescription)
                        self.translationProgress = Double(index + 1) / total
                    }
                }
                
                // Small delay to avoid API rate limiting
                try? await Task.sleep(nanoseconds: 500_000_000)
            }
            
            await MainActor.run {
                self.isTranslatingAll = false
            }
        }
    }
    
    // MARK: - Navigation
    func nextPage() {
        if currentPageIndex < comic.pages.count - 1 {
            currentPageIndex += 1
        }
    }
    
    func previousPage() {
        if currentPageIndex > 0 {
            currentPageIndex -= 1
        }
    }
}
