import SwiftUI
import Foundation

// MARK: - Library ViewModel
class LibraryViewModel: ObservableObject {
    @Published var comics: [ComicBook] = []
    @Published var isImporting = false
    @Published var errorMessage: String?
    @Published var showError = false
    
    // MARK: - Import CBZ File
    func importCBZ(url: URL) {
        isImporting = true
        
        Task {
            do {
                let accessing = url.startAccessingSecurityScopedResource()
                defer {
                    if accessing { url.stopAccessingSecurityScopedResource() }
                }
                
                let images = try CBZParser.parse(url: url)
                
                let pages = images.enumerated().map { index, image in
                    ComicPage(pageNumber: index + 1, originalImage: image)
                }
                
                let title = url.deletingPathExtension().lastPathComponent
                let comic = ComicBook(title: title, pages: pages)
                
                await MainActor.run {
                    self.comics.append(comic)
                    self.isImporting = false
                }
                
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.showError = true
                    self.isImporting = false
                }
            }
        }
    }
    
    // MARK: - Delete Comic
    func deleteComic(at offsets: IndexSet) {
        comics.remove(atOffsets: offsets)
    }
}
