import UIKit
import Foundation
import ZipArchive

// MARK: - CBZ Parser
class CBZParser {
    
    /// Extracts all images from a .cbz file and returns them sorted by filename
    static func parse(url: URL) throws -> [UIImage] {
        let tempDir = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
        
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)
        defer {
            try? FileManager.default.removeItem(at: tempDir)
        }
        
        // CBZ is just a ZIP file - unzip it
        guard SSZipArchive.unzipFile(atPath: url.path, toDestination: tempDir.path) else {
            throw CBZError.extractionFailed
        }
        
        // Find all image files
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: tempDir,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            throw CBZError.noFilesFound
        }
        
        var imageURLs: [URL] = []
        
        for case let fileURL as URL in enumerator {
            let ext = fileURL.pathExtension.lowercased()
            if ["jpg", "jpeg", "png", "webp", "gif"].contains(ext) {
                imageURLs.append(fileURL)
            }
        }
        
        guard !imageURLs.isEmpty else {
            throw CBZError.noImagesFound
        }
        
        // Sort by filename for correct page order
        imageURLs.sort { $0.lastPathComponent < $1.lastPathComponent }
        
        // Load images
        let images = imageURLs.compactMap { url -> UIImage? in
            guard let data = try? Data(contentsOf: url),
                  let image = UIImage(data: data) else { return nil }
            return image
        }
        
        guard !images.isEmpty else {
            throw CBZError.imageLoadFailed
        }
        
        return images
    }
}

// MARK: - CBZ Errors
enum CBZError: LocalizedError {
    case extractionFailed
    case noFilesFound
    case noImagesFound
    case imageLoadFailed
    
    var errorDescription: String? {
        switch self {
        case .extractionFailed: return "فشل في فتح ملف CBZ"
        case .noFilesFound: return "لم يتم العثور على ملفات داخل الأرشيف"
        case .noImagesFound: return "لم يتم العثور على صور في الملف"
        case .imageLoadFailed: return "فشل في تحميل الصور"
        }
    }
}
