# 📚 قارئ الكوميكس بالترجمة العربية

تطبيق iOS لقراءة ملفات CBZ مع ترجمة تلقائية من الإنجليزية للعربية عبر Gemini AI.

---

## ✨ المميزات
- فتح ملفات CBZ مباشرة من الجهاز
- ترجمة صفحة واحدة بضغطة زر
- ترجمة كامل الكوميكس تلقائياً
- حذف النص الإنجليزي واستبداله بالعربي
- واجهة عربية كاملة

---

## 🛠️ طريقة التثبيت

### الخطوة 1: ضع مفتاح Gemini API
افتح الملف:
```
ComicTranslator/Services/GeminiService.swift
```
وابحث عن السطر:
```swift
private let apiKey = "YOUR_GEMINI_API_KEY"
```
استبدل `YOUR_GEMINI_API_KEY` بمفتاحك من:
https://aistudio.google.com/apikey

---

### الخطوة 2: تثبيت CocoaPods
```bash
# تثبيت CocoaPods إذا لم يكن مثبتاً
sudo gem install cocoapods

# تثبيت المكتبات
cd ComicTranslator
pod install
```

---

### الخطوة 3: فتح المشروع
```bash
open ComicTranslator.xcworkspace
```
⚠️ افتح `.xcworkspace` وليس `.xcodeproj`

---

### الخطوة 4: إعداد الـ Signing
1. في Xcode، اختر المشروع من الـ Navigator
2. اختر Target: **ComicTranslator**
3. اذهب لـ **Signing & Capabilities**
4. اختر **Team** من حسابك
5. غيّر **Bundle Identifier** لشيء فريد مثل:
   `com.yourname.comictranslator`

---

### الخطوة 5: البناء
- للمحاكي: اضغط **▶️ Play**
- لجهازك الحقيقي: اختر جهازك ثم اضغط **▶️ Play**
- لملف IPA: **Product → Archive**

---

## 🔧 بناء IPA عبر GitHub Actions (بدون Mac)

### المتطلبات:
1. حساب GitHub
2. Apple Developer Certificate (.p12)
3. Provisioning Profile (.mobileprovision)

### الخطوات:
1. ارفع المشروع على GitHub repository
2. اذهب لـ **Settings → Secrets → Actions**
3. أضف هذه الـ Secrets:

| الاسم | المحتوى |
|-------|---------|
| `CERTIFICATE_BASE64` | شهادتك بصيغة base64: `base64 -i cert.p12` |
| `CERTIFICATE_PASSWORD` | كلمة سر الشهادة |
| `PROVISIONING_PROFILE_BASE64` | البروفايل بصيغة base64: `base64 -i profile.mobileprovision` |

4. اذهب لـ **Actions → Build ComicTranslator IPA → Run workflow**
5. بعد الانتهاء، حمّل الـ IPA من **Artifacts**

---

## 📱 طريقة الاستخدام

1. **إضافة كوميكس**: اضغط زر **+** واختر ملف CBZ
2. **فتح الكوميكس**: اضغط على الغلاف في المكتبة
3. **ترجمة صفحة**: اضغط **"ترجمة الصفحة"** في الأسفل
4. **ترجمة الكل**: اضغط **"ترجمة الكل"** وانتظر

---

## 📦 المكتبات المستخدمة
- **SSZipArchive**: لفك ضغط ملفات CBZ
- **Gemini 1.5 Flash API**: للترجمة الذكية

---

## ⚠️ ملاحظات
- الترجمة تتطلب اتصال بالإنترنت
- كل صفحة تستهلك ~1-2 طلب من Gemini API
- جودة الترجمة تعتمد على وضوح النص في الصورة
