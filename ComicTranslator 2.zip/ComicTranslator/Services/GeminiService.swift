import UIKit
import Foundation

// MARK: - Gemini Translation Service
class GeminiService: ObservableObject {
    
    // ⚠️ ضع مفتاح API هنا
    private let apiKey = "AIzaSyAvVnN3QitribpdGsv4693_oekcPZFMR0Q
"
    private let apiURL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
    
    // MARK: - Translate Comic Page
    func translatePage(_ image: UIImage) async throws -> UIImage {
        // Step 1: Extract text positions from image using Gemini Vision
        let textData = try await extractTextWithPositions(from: image)
        
        // Step 2: Draw Arabic translations over the original image
        let translatedImage = try await drawTranslationsOnImage(image, textData: textData)
        
        return translatedImage
    }
    
    // MARK: - Extract Text + Positions via Gemini Vision
    private func extractTextWithPositions(from image: UIImage) async throws -> [TextBlock] {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            throw TranslationError.imageConversionFailed
        }
        
        let base64Image = imageData.base64EncodedString()
        
        let prompt = """
        You are a comic book translator. Analyze this comic page image carefully.
        
        Find ALL text bubbles, captions, and sound effects.
        For each text element, provide:
        1. The original English text
        2. The Arabic translation (natural, comic-style Arabic)
        3. The approximate position as percentage of image (x, y, width, height) where:
           - x,y is the TOP-LEFT corner
           - all values are 0.0 to 1.0
        
        IMPORTANT: Return ONLY valid JSON, no markdown, no explanation.
        Format exactly like this:
        {
          "textBlocks": [
            {
              "original": "Hello!",
              "arabic": "مرحباً!",
              "x": 0.1,
              "y": 0.05,
              "width": 0.3,
              "height": 0.1
            }
          ]
        }
        
        If no text found, return: {"textBlocks": []}
        """
        
        let requestBody: [String: Any] = [
            "contents": [
                [
                    "parts": [
                        [
                            "inline_data": [
                                "mime_type": "image/jpeg",
                                "data": base64Image
                            ]
                        ],
                        ["text": prompt]
                    ]
                ]
            ],
            "generationConfig": [
                "temperature": 0.1,
                "maxOutputTokens": 2048
            ]
        ]
        
        guard let url = URL(string: "\(apiURL)?key=\(apiKey)") else {
            throw TranslationError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        request.timeoutInterval = 60
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw TranslationError.networkError("لا يوجد استجابة من الخادم")
        }
        
        guard httpResponse.statusCode == 200 else {
            let errorText = String(data: data, encoding: .utf8) ?? "خطأ غير معروف"
            throw TranslationError.apiError("كود الخطأ: \(httpResponse.statusCode) - \(errorText)")
        }
        
        // Parse Gemini response
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = json["candidates"] as? [[String: Any]],
              let firstCandidate = candidates.first,
              let content = firstCandidate["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]],
              let firstPart = parts.first,
              let text = firstPart["text"] as? String else {
            throw TranslationError.parsingError("فشل في قراءة استجابة Gemini")
        }
        
        // Clean JSON response
        let cleanedText = text
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard let jsonData = cleanedText.data(using: .utf8),
              let result = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any],
              let blocksArray = result["textBlocks"] as? [[String: Any]] else {
            // No text found is OK
            return []
        }
        
        return blocksArray.compactMap { block -> TextBlock? in
            guard let original = block["original"] as? String,
                  let arabic = block["arabic"] as? String,
                  let x = block["x"] as? Double,
                  let y = block["y"] as? Double,
                  let width = block["width"] as? Double,
                  let height = block["height"] as? Double else { return nil }
            
            return TextBlock(
                original: original,
                arabic: arabic,
                rect: CGRect(x: x, y: y, width: width, height: height)
            )
        }
    }
    
    // MARK: - Draw Arabic Text Over Image
    private func drawTranslationsOnImage(_ image: UIImage, textData: [TextBlock]) async throws -> UIImage {
        let imageSize = image.size
        let scale = image.scale
        
        UIGraphicsBeginImageContextWithOptions(imageSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        
        // Draw original image
        image.draw(at: .zero)
        
        guard let context = UIGraphicsGetCurrentContext() else {
            throw TranslationError.renderingFailed
        }
        
        for block in textData {
            // Calculate actual pixel rect
            let rect = CGRect(
                x: block.rect.origin.x * imageSize.width,
                y: block.rect.origin.y * imageSize.height,
                width: block.rect.width * imageSize.width,
                height: block.rect.height * imageSize.height
            )
            
            // Cover original English text with white background
            context.setFillColor(UIColor.white.cgColor)
            context.fill(rect)
            
            // Add slight border
            context.setStrokeColor(UIColor.lightGray.cgColor)
            context.setLineWidth(0.5)
            context.stroke(rect)
            
            // Draw Arabic text
            let fontSize = max(rect.height * 0.35, 10)
            let font = UIFont.systemFont(ofSize: fontSize, weight: .medium)
            
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            paragraphStyle.lineBreakMode = .byWordWrapping
            
            let attributes: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.black,
                .paragraphStyle: paragraphStyle
            ]
            
            let padding: CGFloat = 4
            let textRect = rect.insetBy(dx: padding, dy: padding)
            
            block.arabic.draw(in: textRect, withAttributes: attributes)
        }
        
        guard let resultImage = UIGraphicsGetImageFromCurrentImageContext() else {
            throw TranslationError.renderingFailed
        }
        
        return resultImage
    }
}

// MARK: - Text Block Model
struct TextBlock {
    let original: String
    let arabic: String
    let rect: CGRect
}

// MARK: - Translation Errors
enum TranslationError: LocalizedError {
    case imageConversionFailed
    case invalidURL
    case networkError(String)
    case apiError(String)
    case parsingError(String)
    case renderingFailed
    
    var errorDescription: String? {
        switch self {
        case .imageConversionFailed: return "فشل في تحويل الصورة"
        case .invalidURL: return "رابط API غير صالح"
        case .networkError(let msg): return "خطأ في الشبكة: \(msg)"
        case .apiError(let msg): return "خطأ في API: \(msg)"
        case .parsingError(let msg): return "خطأ في قراءة البيانات: \(msg)"
        case .renderingFailed: return "فشل في رسم الترجمة على الصورة"
        }
    }
}
